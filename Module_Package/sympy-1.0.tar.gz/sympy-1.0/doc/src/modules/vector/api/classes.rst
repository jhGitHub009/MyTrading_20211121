=============================================
Essential Classes in sympy.vector (doctrings)
=============================================

CoordSysCartesian
=================

.. autoclass:: sympy.vector.coordsysrect.CoordSysCartesian
   :members:

   .. automethod:: sympy.vector.coordsysrect.CoordSysCartesian.__init__


Vector
======

.. autoclass:: sympy.vector.vector.Vector
   :members:


Dyadic
======

.. autoclass:: sympy.vector.dyadic.Dyadic
   :members:


Del
===

.. autoclass:: sympy.vector.deloperator.Del
   :members:
