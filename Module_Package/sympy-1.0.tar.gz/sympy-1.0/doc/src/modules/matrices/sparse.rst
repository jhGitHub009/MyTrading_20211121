Sparse Matrices
===============

.. module:: sympy.matrices.sparse

SparseMatrix Class Reference
----------------------------
.. autoclass:: SparseMatrix
   :members:
.. autoclass:: MutableSparseMatrix
   :members:

ImmutableSparseMatrix Class Reference
-------------------------------------
.. autoclass:: sympy.matrices.immutable.ImmutableSparseMatrix
   :members:
