=======
PKGDATA
=======

.. automodule:: sympy.utilities.pkgdata
   :members:
