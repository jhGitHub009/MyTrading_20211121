========
Lambdify
========

.. automodule:: sympy.utilities.lambdify
   :members:
