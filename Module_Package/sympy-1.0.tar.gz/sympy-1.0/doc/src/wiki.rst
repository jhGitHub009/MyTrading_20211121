Wiki
====

SymPy has a public wiki located at http://wiki.sympy.org. Users should feel
free to contribute to this wiki anything interesting/useful.

FAQ
---

`FAQ <https://github.com/sympy/sympy/wiki/Faq>`_ is one of the most useful
wiki pages. It has answers to frequently-asked questions.
