raise DeprecationWarning("""DEPRECATED:

After Popular request and decision from the BDFL:
`IPython.terminal.ptshell` has been moved back to `IPython.terminal.interactiveshell`
during the beta cycle (after IPython 5.0.beta3) Sorry about that. 

This file will be removed in 5.0 rc or final.
""")
