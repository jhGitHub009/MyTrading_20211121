def test_version():
    import odo
    assert odo.__version__ != 'unknown'
