.. toctree::
    :maxdepth: 2
    :hidden:

    migrate_to_0.9
    installation
    quickstart
    connect_to_workbook
    syntax_overview
    datastructures
    vba
    debugging
    matplotlib
    udfs
    converters
    command_line
    missing_features
    r_and_julia
    api





