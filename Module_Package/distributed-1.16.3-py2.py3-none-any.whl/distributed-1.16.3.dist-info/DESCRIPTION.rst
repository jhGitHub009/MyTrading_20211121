Distributed
===========

A library for distributed computation.  See documentation_ for more details.

.. _documentation: https://distributed.readthedocs.io/en/latest


