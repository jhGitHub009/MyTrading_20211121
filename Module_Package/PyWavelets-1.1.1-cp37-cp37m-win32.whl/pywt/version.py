
# THIS FILE IS GENERATED FROM PYWAVELETS SETUP.PY
short_version = '1.1.1'
version = '1.1.1'
full_version = '1.1.1'
git_revision = '7b2f66b0ef9196fa91bba550a81d1870f5933a36'
release = True

if not release:
    version = full_version
