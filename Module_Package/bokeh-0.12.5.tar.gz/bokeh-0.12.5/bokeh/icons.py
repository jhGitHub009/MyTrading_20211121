"""

.. warning::
    FontAwesome icons and the associated ``bokeh.icons`` module were removed in
    the Bokeh 0.12.4 release. Please see the :bokeh-tree:`examples/custom/font-awesome`
    directory for a demonstration of how to use these icons with a custom extension.

"""

import warnings
warnings.warn("FontAwesome icons and the associated bokeh.icons module were removed in the Bokeh 0.12.4 release. \
Please see the examples/custom/font-awesome directory for a demonstration of how to use these icons with a custom extension.")
del warnings
