import * as DOM from "core/dom";

export default (): HTMLElement => {
  return <div class="bk-markup"></div>
}
