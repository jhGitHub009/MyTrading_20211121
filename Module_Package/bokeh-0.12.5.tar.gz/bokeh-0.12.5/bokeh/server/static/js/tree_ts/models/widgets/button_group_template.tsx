import * as DOM from "core/dom";

export default (): HTMLElement => {
  return <div class="bk-bs-btn-group" data-bk-bs-toggle="buttons"></div>
}
