'''

'''
from __future__ import absolute_import

# TODO (havocp) this class may be unused
class ServerTask(object):
    '''

    '''
    pass
