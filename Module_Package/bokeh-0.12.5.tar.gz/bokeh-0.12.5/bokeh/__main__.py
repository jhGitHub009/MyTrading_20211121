import sys

from bokeh.command.bootstrap import main as _main

def main():
    # Main entry point (see setup.py)
    _main(sys.argv)

if __name__ == "__main__":
    main()
