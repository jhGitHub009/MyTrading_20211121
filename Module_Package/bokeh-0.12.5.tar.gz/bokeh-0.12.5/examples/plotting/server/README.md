All the examples in this directory illustrate how to use the Bokeh server
from simple python scripts. This can also be useful when working with
Jupyter notebooks.

To run the examples, first start a Bokeh server:

    bokeh serve

Then execute any of the scripts in this directory, e.g.

    python animated.py

The document should automatically open in a new tab in your browser.
