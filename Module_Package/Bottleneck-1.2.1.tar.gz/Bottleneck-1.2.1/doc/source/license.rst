.. include:: ../../bottleneck/LICENSE
