# -*- coding: utf-8 -*-

#==============================================================================
# The following statement is required to register this 3rd party plugin:
#==============================================================================
from .breakpoints import Breakpoints as PLUGIN_CLASS
