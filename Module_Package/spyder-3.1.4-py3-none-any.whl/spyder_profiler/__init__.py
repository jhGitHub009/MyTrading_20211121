# -*- coding: utf-8 -*-

#==============================================================================
# The following statement is required to register this 3rd party plugin:
#==============================================================================
from .profiler import Profiler as PLUGIN_CLASS
