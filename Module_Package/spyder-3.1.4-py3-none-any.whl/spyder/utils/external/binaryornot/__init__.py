__author__ = 'Audrey Roy'
__email__ = 'audreyr@gmail.com'
__version__ = '0.4.0'
