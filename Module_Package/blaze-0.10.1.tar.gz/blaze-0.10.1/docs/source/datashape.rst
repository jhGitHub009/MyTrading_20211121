=========
Datashape
=========

Blaze uses datashape, a data layout language for array programming,
as its type system.

* Documentation_
* Source_

.. _Source: https://github.com/blaze/datashape
.. _Documentation: http://datashape.pydata.org/
