"""Tornado eventloop integration for pyzmq"""

from zmq.eventloop.ioloop import IOLoop

__all__ = ['IOLoop']
